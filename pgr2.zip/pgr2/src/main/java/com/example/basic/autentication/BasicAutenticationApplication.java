package com.example.basic.autentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicAutenticationApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicAutenticationApplication.class, args);
	}

}
