package com.example.commandlinerunner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommandlinerunnerApplicationTests {

	@Test
	void contextLoads() {
	}

}
