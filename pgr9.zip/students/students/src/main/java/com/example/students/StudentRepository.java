package com.example.students;

public interface StudentRepository {

}
