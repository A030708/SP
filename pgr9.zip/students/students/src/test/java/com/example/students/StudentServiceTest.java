package com.example.students;

public class StudentServiceTest {

}
