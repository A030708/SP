package com.example.program9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Program9Application {

	public static void main(String[] args) {
		SpringApplication.run(Program9Application.class, args);
	}

}
