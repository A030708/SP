package com.example.program9;
import com.example.program9.StudentService;
import com.example.program9.StudentRepository;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


public class StudentServiceTest {
    @Mock
    StudentRepository repo;

    @InjectMocks
    StudentService service;

    public StudentServiceTest() { MockitoAnnotations.openMocks(this); }

    @Test
    void testCreateStudent() {
        Student s = new Student("Amy","CSE", 88);
        when(repo.save(any(Student.class))).thenReturn(s);
        Student res = service.createStudent(s);
        assertNotNull(res);
        assertEquals("Amy", res.getName());
        verify(repo, times(1)).save(s);
    }

    @Test
    void testGetStudentById() {
        Student s = new Student("Ben","CSE",75);
        s.setId(1L);
        when(repo.findById(1L)).thenReturn(Optional.of(s));
        var opt = service.getStudentById(1L);
        assertTrue(opt.isPresent());
        assertEquals("Ben", opt.get().getName());
        verify(repo, times(1)).findById(1L);
    }

}
