package com.example.program9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Program9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
