package com.example.prgm5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prgm5Application {

	public static void main(String[] args) {
		SpringApplication.run(Prgm5Application.class, args);
	}

}
