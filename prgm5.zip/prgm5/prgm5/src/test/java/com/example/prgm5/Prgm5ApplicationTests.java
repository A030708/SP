package com.example.prgm5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prgm5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
