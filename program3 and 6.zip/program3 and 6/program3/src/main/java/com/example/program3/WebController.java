package com.example.program3;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller

public class WebController {
	@GetMapping("/home")
    public String home(@AuthenticationPrincipal UserDetails user, Model m) {
        m.addAttribute("username", user.getUsername());
        return "home";
    }
	@GetMapping("/login")
    public String login() { return "login"; }


}
