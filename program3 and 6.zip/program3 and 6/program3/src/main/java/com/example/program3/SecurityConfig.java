package com.example.program3;
import org.springframework.context.annotation.Bean;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
@Configuration

public class SecurityConfig {
    @Bean
    public InMemoryUserDetailsManager users() {
        var u = User.withDefaultPasswordEncoder()
            .username("user").password("pass").roles("USER").build();
        return new InMemoryUserDetailsManager(u);
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf().disable()
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/h2-console/**", "/actuator/**").permitAll()
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                    .loginPage("/login").permitAll()
                    .defaultSuccessUrl("/home", true)
                )
                .logout(logout -> logout.permitAll());

            return http.build();
    }
}
